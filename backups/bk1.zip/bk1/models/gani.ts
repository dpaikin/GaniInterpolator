'use-strict'

namespace Models {

    export type Gani = {

        filename: string
        frames: Map<number, Frame>
        totalLength: number
        data: string[]
        sounds?: Sound[]

    } | null

    export type Frame = {

        id: number
        directions: Map<number, Sprite[]>
        delay: number

    } | null

    export type Sprite = {

        spriteId: number
        x: number
        y: number

    }
    
    export type Sound = {

        filename: string
        x: number
        y: number

    }
}
